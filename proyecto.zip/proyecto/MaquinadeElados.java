import java.util.Scanner;

public class MaquinadeElados {

    public static final String[] sabores = { "fresa", "vainilla", "maraculla", "chocolate","limon","Pistacho","naranja","Ron con pasas" ,"Brownie","Frambuesa","galleta"};
    public int precio = 3000;
    public int cantidadBolas;
    //corregir despues*
    public String sabor1;
    public String sabor2;
    public String sabor3;
    public String sabor4;


    public void MaquinadeElados(int precio, int cantidadBolas, String saborhelado) {

        this.precio = precio;
        this.cantidadBolas = cantidadBolas;
        this.sabor1 = saborhelado;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setCantidadbolas(int precio) {
        this.precio = precio;
    }

    public void setsabor(String sabor) {
        this.sabor1 = sabor;
    }

    public int getPrecio() {
        return this.precio;
    }

    public int getcantidadBolas() {
        return this.cantidadBolas;
    }

    public String getsaborhelado() {
        return this.sabor1;
    }
    Scanner entrada = new Scanner(System.in);
    Scanner entrada2 = new Scanner(System.in);
    Scanner entrada3 = new Scanner(System.in);

    public void menu (){
        System.out.println("Hola aqui estalos sabores disponibles");
        System.out.println("------------------------------------------");
        for (int i = 0; i < sabores.length; i++) {
            System.out.println((i + 1) + ". " + sabores[i]);
          
        }
        System.out.println("------------------------------------------");
    }

    public void PedirElados() {
        
     
        System.out.println("cuantas bolas de helado quieres?\nel maximo que puedes elejir son 4 bolas!");

        this.cantidadBolas = entrada.nextInt();
       
        boolean estado = false ; 

              switch (getcantidadBolas()) {
                case 1:
                      System.out.println("que sabor vas a elegir ?: ");
                      
                        this.sabor1= entrada2.nextLine();
                        
                        for(int i = 0 ; i<sabores.length; i++){
                        if (sabores[i].equalsIgnoreCase(this.sabor1)){
                            estado = true; 
                        }
                         
                        }
                        if (estado){
                           System.out.println("a qui esta su eslado sabor a "+this.sabor1);
                       }else{
                           System.out.println("ups no tenemos ese sabor");
                        
              
                        }
                        break;
               case 2:
                     System.out.println("de que sabor va a elegir la primera bola?");
                       this.sabor1 = entrada2.nextLine(); 
                       System.out.println("de que sabor va a elegir la segunda bola?");
                       this.sabor2 = entrada2.nextLine(); 
                       for(int i = 0 ; i<sabores.length; i++){
                        
                        if (sabores[i].equalsIgnoreCase(this.sabor1) || sabores[i].equalsIgnoreCase(this.sabor2)){
                            estado = true; 
                        }
                         
                        }
                        if (estado){
                           System.out.println("a qui esta su elado de sabor  a: "+this.sabor1+" con "+this.sabor2);
                       }else{
                           System.out.println("ups no tenemos esos sabores");
                        
              
                        }
                        break; 
                  case 3 : 
                  System.out.println("de que sabor va a elegir la primera bola?");
                  this.sabor1 = entrada2.nextLine(); 
                  System.out.println("de que sabor va a elegir la segunda bola?");
                  this.sabor2 = entrada2.nextLine(); 
                  System.out.println("de que sabor va a elegir la tercera bola?");
                  this.sabor3 = entrada2.nextLine(); 
                
                  for(int i = 0 ; i<sabores.length; i++){
                   
                   if (sabores[i].equalsIgnoreCase(this.sabor1) || sabores[i].equalsIgnoreCase(this.sabor2)|| sabores[i].equalsIgnoreCase(this.sabor3)){
                       estado = true; 
                   }
                    
                   }
                   if (estado){
                      System.out.println("a qui esta su elado de sabor a : "+this.sabor1+" con "+this.sabor2+ " y "+this.sabor3);
                  }else{
                      System.out.println("ups no tenemos esos sabores");
                   
         
                   }
                    break;

                    case 4 : 
                    System.out.println("de que sabor va aelegir la primera bola?");
                    this.sabor1 = entrada2.nextLine(); 
                    System.out.println("de que sabor va aelegir la segunda bola?");
                    this.sabor2 = entrada2.nextLine(); 
                    System.out.println("de que sabor va aelegir la tercera bola?");
                    this.sabor3 = entrada2.nextLine(); 
                    System.out.println("de que sabor va aelegir la cuarta bola?");
                    this.sabor4 = entrada2.nextLine(); 
              
                    for(int i = 0 ; i<sabores.length; i++){
                     
                     if (sabores[i].equalsIgnoreCase(this.sabor1) || sabores[i].equalsIgnoreCase(this.sabor2)|| sabores[i].equalsIgnoreCase(this.sabor3) ||sabores[i].equalsIgnoreCase(this.sabor4)){
                         estado = true; 
                     }
                      
                     }
                     if (estado){
                        System.out.println("a qui esta su elado de sabor a : "+this.sabor1+" con "+this.sabor2+" con "+this.sabor3+" y " +this.sabor4);
                    }else{
                        System.out.println("ups no tenemos esos sabores");

                    }
                default:
                System.out.println("no puedes elegir mas de 4 bolas!");
                    break;
              
        }
       
     
    }
    public void maquina (){
        int opcion ;
        do{
            System.out.println("\nCarrito de Helados");
            System.out.println("1. Mostrar Menú");
            System.out.println("2. pedir elado");
            System.out.println("0. salir");
            System.out.print("Ingresa una opción: ");
             opcion = entrada3.nextInt();
            switch (opcion) {
            case 1:
               menu();
                break;
            case 2:
            PedirElados() ;
                break;
           
            default:
                System.out.println("Opción inválida.");

            }
                
    }while(opcion !=0);
}

    public static void main(String[] args) {
        MaquinadeElados maquina1 = new MaquinadeElados();
       maquina1.maquina();

    }

}